# KNZ PANEL — Android Studio / Kotlin

Projeto inicial de um painel flutuante Android com tema preto e branco.

## O que está incluído
- Tela inicial para ativar e fechar o painel.
- Solicitação da permissão Android de sobreposição.
- Serviço em primeiro plano para manter o painel flutuante ativo.
- Painel arrastável.
- Botões ON/OFF e sliders demonstrativos.
- Nenhum recurso altera o Free Fire, automatiza ações, revela jogadores ou injeta código no jogo.

## Como abrir
1. Extraia o ZIP.
2. Abra a pasta `KNZ_PANEL` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Conecte um celular Android ou inicie um emulador.
5. Execute o app pelo botão Run.
6. Toque em **ATIVAR PAINEL FLUTUANTE**.
7. Nas configurações do Android, permita que KNZ PANEL apareça sobre outros apps.
8. Volte ao aplicativo e toque novamente no botão.

## Gerar APK
No Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
O APK de depuração será gerado em `app/build/outputs/apk/debug/`.

## Requisitos
- Android Studio com suporte ao Android Gradle Plugin 8.7.3.
- JDK 17.
- Android SDK 35.

## Observações
Este é um projeto-base. Teste em seu próprio aparelho. A permissão de sobreposição é concedida pelo usuário nas configurações do Android. O aplicativo não solicita acesso a arquivos, contatos, localização ou dados da conta do jogo.
