package com.knz.panel

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = 0xFF080808.toInt()
    private val white = 0xFFFFFFFF.toInt()
    private val muted = 0xFFAAAAAA.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            text = "KNZ PANEL"
            textSize = 30f
            setTextColor(white)
            gravity = Gravity.CENTER
            letterSpacing = 0.16f
        }
        val subtitle = TextView(this).apply {
            text = "PAINEL FLUTUANTE • MODO DEMONSTRAÇÃO"
            textSize = 11f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 28)
        }
        val info = TextView(this).apply {
            text = "Este aplicativo demonstra controles visuais e ferramentas locais.\nNão altera o Free Fire nem oferece assistência de mira, ESP ou automação."
            textSize = 14f
            setTextColor(white)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 28)
        }
        val start = Button(this).apply {
            text = "ATIVAR PAINEL FLUTUANTE"
            setTextColor(bg)
            setBackgroundColor(white)
            setOnClickListener { requestOverlayAndStart() }
        }
        val stop = Button(this).apply {
            text = "FECHAR PAINEL"
            setOnClickListener {
                stopService(Intent(this@MainActivity, FloatingPanelService::class.java))
                Toast.makeText(this@MainActivity, "Painel fechado", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(info)
        layout.addView(start, LinearLayout.LayoutParams(-1, -2))
        layout.addView(stop, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12 })
        setContentView(layout)
    }

    private fun requestOverlayAndStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            Toast.makeText(this, "Ative 'Permitir sobreposição' e volte ao KNZ PANEL.", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, FloatingPanelService::class.java))
        Toast.makeText(this, "Painel ativado", Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        // Após conceder a permissão nas configurações, o usuário pode tocar no botão novamente.
    }
}
