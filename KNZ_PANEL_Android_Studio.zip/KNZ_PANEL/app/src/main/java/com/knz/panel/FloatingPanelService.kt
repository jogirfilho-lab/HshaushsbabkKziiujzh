package com.knz.panel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class FloatingPanelService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private lateinit var params: WindowManager.LayoutParams
    private val white = 0xFFFFFFFF.toInt()
    private val black = 0xFF090909.toInt()
    private val gray = 0xFF242424.toInt()
    private val textGray = 0xFFBDBDBD.toInt()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(7, buildNotification())
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun showPanel() {
        if (panel != null) return

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(black)
        }

        val header = TextView(this).apply {
            text = "KNZ PANEL     •     DEMO"
            textSize = 15f
            setTextColor(white)
            setPadding(4, 4, 4, 14)
        }
        root.addView(header)

        val dragHint = TextView(this).apply {
            text = "SEGURE AQUI PARA MOVER"
            textSize = 9f
            setTextColor(textGray)
            setPadding(4, 0, 4, 10)
        }
        root.addView(dragHint)

        addToggle(root, "FPS INDICATOR", "Indicador demonstrativo ligado")
        addToggle(root, "PERFIL DE DESEMPENHO", "Perfil local selecionado")
        addToggle(root, "TOQUE / RESPOSTA", "Teste visual de toque")
        addSlider(root, "SENSIBILIDADE (DEMO)", 0, 100, 50)
        addSlider(root, "NÍVEL DE DESEMPENHO (DEMO)", 0, 100, 70)

        val close = Button(this).apply {
            text = "FECHAR PAINEL"
            setTextColor(white)
            setBackgroundColor(gray)
            setOnClickListener { stopSelf() }
        }
        root.addView(close)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

        params = WindowManager.LayoutParams(
            dp(280), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(16)
            y = dp(100)
        }

        val touchListener = object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX - (event.rawX - touchX).toInt()
                        params.y = startY + (event.rawY - touchY).toInt()
                        windowManager.updateViewLayout(root, params)
                        return true
                    }
                }
                return false
            }
        }
        dragHint.setOnTouchListener(touchListener)
        header.setOnTouchListener(touchListener)

        panel = root
        windowManager.addView(root, params)
    }

    private fun addToggle(parent: LinearLayout, label: String, enabledMessage: String) {
        var enabled = false
        val button = Button(this).apply {
            text = "$label: OFF"
            textSize = 11f
            setTextColor(white)
            setBackgroundColor(gray)
            setOnClickListener {
                enabled = !enabled
                text = "$label: ${if (enabled) "ON" else "OFF"}"
                contentDescription = if (enabled) enabledMessage else "$label desligado"
            }
        }
        parent.addView(button, LinearLayout.LayoutParams(-1, dp(44)).apply {
            bottomMargin = dp(7)
        })
    }

    private fun addSlider(parent: LinearLayout, label: String, min: Int, max: Int, initial: Int) {
        val title = TextView(this).apply {
            text = "$label: $initial"
            textSize = 10f
            setTextColor(white)
            setPadding(3, 8, 3, 0)
        }
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = initial - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    title.text = "$label: ${progress + min}"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        parent.addView(title)
        parent.addView(seek)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "knz_panel_channel", "KNZ PANEL", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, "knz_panel_channel")
                .setContentTitle("KNZ PANEL ativo")
                .setContentText("Painel flutuante demonstrativo em execução")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("KNZ PANEL ativo")
                .setContentText("Painel flutuante demonstrativo em execução")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build()
        }
    }

    override fun onDestroy() {
        panel?.let {
            if (it.isAttachedToWindow) windowManager.removeView(it)
        }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
